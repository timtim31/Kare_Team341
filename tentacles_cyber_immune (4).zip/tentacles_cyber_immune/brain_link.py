from src.prioritizer.queue import CommandPrioritizer
from src.ai.security_monitor import SecurityMonitor


class CentralControlSystem:
    def __init__(self, inhibitor, drivers):
        self.inhibitor = inhibitor
        self.drivers = drivers
        self.prioritizer = CommandPrioritizer()
        self.security_monitor = SecurityMonitor()
        print("[CCS] Центральная система управления инициализирована")

    def submit(self, request, sender="operator_api",
               biometric_token="USER_4102", metadata=None):
        """Принять команду, расставить приоритет, выполнить через ингибитор"""

        # Шаг 1 — добавить в очередь с приоритетом
        self.prioritizer.add(request)
        print(f"[CCS] Очередь команд: {self.prioritizer.peek_all()}")

        # Шаг 2 — извлечь команду с наивысшим приоритетом
        next_request = self.prioritizer.pop()

        # Шаг 3 — передать в ингибитор на проверку и выполнение
        success, message = self.inhibitor.authorize_and_execute(
            sender=sender,
            request=next_request,
            callback=self.drivers.execute,
            biometric_token=biometric_token,
            metadata=metadata
        )

        # Шаг 4 — сообщить монитору безопасности о результате
        if not success:
            scenario_id = message.split(":")[0] if "SCENARIO_" in message else "UNKNOWN"
            self.security_monitor.record_blocked(scenario_id, message)

            # Если обнаружена серия атак — экстренная блокировка всей системы
            if self.security_monitor.is_under_attack():
                print("[CCS] ⚠️  АТАКА ОБНАРУЖЕНА — экстренная блокировка системы!")
                self.inhibitor.is_locked = True
        else:
            self.security_monitor.record_success()

        return success, message

    def get_status(self):
        """Полный статус системы включая безопасность и очередь"""
        return {
            "arm_states": self.inhibitor.arm_states,
            "system_locked": self.inhibitor.is_locked,
            "status": "Active" if not self.inhibitor.is_locked else "LOCKED",
            "security": self.security_monitor.get_stats(),
            "queue_size": len(self.prioritizer.queue)
        }

    def emergency_lock(self):
        """Аварийная блокировка — очищает очередь и блокирует систему"""
        print("[CCS] 🚨 СИГНАЛ АВАРИЙНОЙ БЛОКИРОВКИ")
        self.inhibitor.is_locked = True
        self.prioritizer.clear()

    def reset(self):
        """Полный сброс системы (для тестов и отладки)"""
        self.inhibitor.is_locked = False
        for arm_id in self.inhibitor.arm_states:
            self.inhibitor.arm_states[arm_id] = "IDLE"
        self.prioritizer.clear()
        self.security_monitor.reset()
        self.drivers.reset()
        print("[CCS] Система полностью сброшена")