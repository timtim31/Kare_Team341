policies = (
    {"src": "operator",          "dst": "neural_interface"},
    {"src": "neural_interface",  "dst": "central_system"},
    {"src": "chip_inhibitor",    "dst": "central_system"},
    {"src": "central_system",    "dst": "prioritizer"},
    {"src": "central_system",    "dst": "audit_log"},
    {"src": "prioritizer",       "dst": "drive_control"},
    {"src": "ai_module",         "dst": "security_monitor"},
    {"src": "security_monitor",  "dst": "chip_inhibitor"},
    {"src": "drive_control",     "dst": "actuator"},
    {"src": "actuator",          "dst": "overload_monitor"},
    {"src": "overload_monitor",  "dst": "emergency_interface"},
    {"src": "operator_api",      "dst": "central_system"},
)

TOPOLOGY_POLICIES = policies  # алиас для обратной совместимости

CRITICAL_SCENARIOS = {"SCENARIO_08", "SCENARIO_12", "SCENARIO_14"}


def check_operation(id, details) -> bool:
    """ Проверка возможности совершения обращения. """
    src: str = details.get("source")
    dst: str = details.get("deliver_to")

    if not all((src, dst)):
        return False

    print(f"[info] checking policies for event {id}, {src}->{dst}")

    return {"src": src, "dst": dst} in policies