from flask import Flask, request, jsonify
from idl.movement import MovementRequest, TargetType


def create_app(ccs):
    app = Flask(__name__)
    print("[SERVER] Flask-приложение создано")

    @app.route('/status', methods=['GET'])
    def get_status():
        return jsonify(ccs.get_status()), 200

    @app.route('/status/security', methods=['GET'])
    def security_status():
        """Отдельный эндпоинт статуса монитора безопасности"""
        return jsonify(ccs.security_monitor.get_stats()), 200

    @app.route('/commands', methods=['POST'])
    def send_command():
        data = request.json
        try:
            move_req = MovementRequest(
                arm_id=data['arm_id'],
                vector_x=data['vector_x'],
                vector_y=data['vector_y'],
                power=data['power'],
                target_type=TargetType[data['target_type'].upper()]
            )

            print(f"[SERVER] Получена команда: Arm #{move_req.arm_id} -> {move_req.target_type.name}")

            success, message = ccs.submit(
                request=move_req,
                sender=data.get('sender', 'operator_api'),
                biometric_token=data.get('biometric_id', 'USER_4102'),
                metadata=data.get('metadata', {})
            )

            if success:
                return jsonify({"status": "executed", "message": message}), 200
            return jsonify({"status": "REJECTED", "message": message}), 403

        except Exception as e:
            print(f"[SERVER ERROR] {e}")
            return jsonify({"status": "error", "message": str(e)}), 400

    @app.route('/settings', methods=['PUT'])
    def update_settings():
        data = request.json
        if 'lock' in data:
            ccs.inhibitor.is_locked = data['lock']
            return jsonify({"status": "updated", "lock": ccs.inhibitor.is_locked}), 200
        return jsonify({"status": "no changes"}), 400

    @app.route('/emergency-stop', methods=['DELETE'])
    def emergency_stop():
        ccs.emergency_lock()
        return jsonify({"status": "EMERGENCY LOCKDOWN ACTIVATED"}), 200

    @app.route('/commands', methods=['OPTIONS'])
    def options_commands():
        return jsonify({"allowed_methods": ["GET", "POST", "OPTIONS", "DELETE"]}), 200

    @app.route('/debug/reset', methods=['POST'])
    def debug_reset():
        ccs.reset()
        return jsonify({"status": "reset_ok"}), 200

    print("[SERVER] Маршруты зарегистрированы")
    return app