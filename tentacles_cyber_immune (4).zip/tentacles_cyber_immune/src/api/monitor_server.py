import sys
import os
sys.path.insert(0, '/app')

from flask import Flask, jsonify
from src.ai.security_monitor import SecurityMonitor
from src.drivers.overload_monitor import OverloadMonitor

app = Flask(__name__)
sm = SecurityMonitor()
om = OverloadMonitor()

@app.route('/health')
def health():
    return jsonify({'status': 'ok', 'service': 'security_monitor'})

@app.route('/security/stats')
def stats():
    return jsonify(sm.get_stats())

@app.route('/overload/stats')
def overload():
    return jsonify(om.get_stats())

if __name__ == '__main__':
    print('[MONITOR] Монитор безопасности запущен на порту 5001')
    app.run(host='0.0.0.0', port=5001)
